# ui.py
import asyncio
import time
import threading
import flet as ft
import matplotlib.pyplot as plt
from flet_charts import MatplotlibChartWithToolbar

import hardware
import logic

async def build(page: ft.Page):
    page.title = "Casa Inteligente"
    page.theme_mode = ft.ThemeMode.DARK
    page.scroll = ft.ScrollMode.AUTO
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    hardware.init_hardware(
        logic.dht_callback,
        logic.ldr_callback,
        logic.sonar_callback,
        logic.pir_callback
    )

    # ================= DHT =================
    bar_h = 220
    bar_w = 60

    temp_value = ft.Text()
    hum_value = ft.Text()

    temp_fill = ft.Container(width=bar_w, height=0, bgcolor="red")
    hum_fill = ft.Container(width=bar_w, height=0, bgcolor="blue")

    temp_bar = ft.Container(
        content=ft.Column([temp_fill], alignment=ft.MainAxisAlignment.END),
        width=bar_w,
        height=bar_h,
        bgcolor="grey"
    )

    hum_bar = ft.Container(
        content=ft.Column([hum_fill], alignment=ft.MainAxisAlignment.END),
        width=bar_w,
        height=bar_h,
        bgcolor="grey"
    )

    # ===== GRÁFICO =====
    samples = 60
    x = list(range(samples))
    tdata = [0]*samples
    hdata = [0]*samples

    fig, ax = plt.subplots(figsize=(5, 3))
    ax.set_xlim(0, samples)
    ax.set_ylim(0, 100)
    ax.set_title("Temperatura e Humidade em Tempo Real")
    ax.set_ylabel("Valores Medidos")
    ax.set_xlabel("Tempo (s)")
    ax.grid(axis="y", linestyle="--", alpha=0.5)

    lt, = ax.plot(x, tdata, color="red", label="Temperatura")
    lh, = ax.plot(x, hdata, color="blue", label="Humidade")
    ax.legend()

    chart = MatplotlibChartWithToolbar(
        figure=fig,
        height=300
    )

    dht_box = ft.Container(
        padding=15,
        bgcolor="black",
        border_radius=12,
        content=ft.Column([
            ft.Text("DHT11 – Pino 11", weight="bold"),
            ft.Row([
                ft.Column([ft.Text("Temperatura"), temp_bar, temp_value]),
                ft.Column([ft.Text("Humidade"), hum_bar, hum_value]),
                chart
            ], spacing=30)
        ])
    )

    # ================= LDR =================
    ldr_bar = ft.ProgressBar(width=300, color="yellow")
    ldr_text = ft.Text()

    ldr_box = ft.Container(
        padding=15,
        bgcolor="black",
        border_radius=12,
        content=ft.Column([
            ft.Text("Sensor de Luminosidade (LDR) – A0", weight="bold"),
            ldr_text,
            ldr_bar
        ])
    )

    # ================= DISTÂNCIA =================
    dist_bar = ft.ProgressBar(width=300, color="green")
    dist_text = ft.Text()

    dist_box = ft.Container(
        padding=15,
        bgcolor="black",
        border_radius=12,
        content=ft.Column([
            ft.Text("Sensor Ultrassónico – TRIG 8 / ECHO 9", weight="bold"),
            dist_text,
            dist_bar
        ])
    )




    # ================= VENTOINHA =================
    led_size = 40
    fan_led = ft.Icon(ft.Icons.CIRCLE, size=led_size)
    fan_text = ft.Text()

    def fan_on(e): logic.fan_state["manual"] = True
    def fan_off(e): logic.fan_state["manual"] = False

    fan_box = ft.Container(
        padding=15,
        bgcolor="black",
        border_radius=12,
        content=ft.Column([
            ft.Text("Ventoinha – Manual / Automática", weight="bold"),
            fan_led,
            fan_text,
            ft.Row([
                ft.Button("Ligar", on_click=fan_on),
                ft.Button("Desligar", on_click=fan_off)
            ])
        ])
    )

    # ================= LOOP =================
    async def loop():
        while True:
            temp = logic.temperature
            hum = logic.humidity

            temp_value.value = f"{temp:.1f} °C"
            hum_value.value = f"{hum:.1f} %"

            temp_fill.height = min((temp/100)*bar_h, bar_h)
            hum_fill.height = min((hum/100)*bar_h, bar_h)

            tdata.append(temp); tdata.pop(0)
            hdata.append(hum); hdata.pop(0)
            lt.set_ydata(tdata)
            lh.set_ydata(hdata)
            chart.figure.canvas.draw_idle()

            ldr_v = ldr_value * 5 / 1023
            ldr_text.value = f"Luminosidade: {ldr_v:.2f} V"
            ldr_bar.value = ldr_v / 5

            dist_text.value = f"Distância: {distance_cm/100:.2f} m"
            dist_bar.value = min(distance_cm/200, 1)



            now = time.time()
            run = logic.fan_should_run(now)
            hardware.set_fan(run)

            if logic.fan_state["manual"]:
                fan_text.value = "Manual"
            elif logic.fan_auto_active(now):
                fan_text.value = f"Auto ({logic.fan_auto_until-now:.1f}s)"
            else:
                fan_text.value = "Off"

            fan_led.color = "green" if run else "red"

            page.update()
            await asyncio.sleep(0.2)

    asyncio.create_task(loop())

    page.add(
        ft.Column([
            dht_box,
             ft.Row([ldr_box, dist_box], spacing=20, alignment=ft.MainAxisAlignment.CENTER),
            fan_box
        ], spacing=20)
    )
