# ui.py
import flet as ft
import asyncio
import hardware
import logic
import matplotlib.pyplot as plt
from flet_charts import MatplotlibChartWithToolbar

async def build(page: ft.Page):
    page.title = "Casa Inteligente – Arduino + Flet"
    page.theme_mode = ft.ThemeMode.DARK
    page.scroll = ft.ScrollMode.AUTO

    # ================= DHT – BARRAS + GRÁFICO =================
    bar_width = 60
    bar_height = 220

    # Texto dos valores
    temp_value = ft.Text("0.0 °C")
    hum_value = ft.Text("0.0 %")

    # Barras internas (preenchimento)
    temp_fill = ft.Container(width=bar_width, height=0, bgcolor="red")
    hum_fill = ft.Container(width=bar_width, height=0, bgcolor="blue")

    # Barras externas (background cinza)
    temp_bar = ft.Container(
        content=ft.Column([temp_fill], alignment=ft.MainAxisAlignment.END),
        width=bar_width,
        height=bar_height,
        bgcolor="grey"
    )

    hum_bar = ft.Container(
        content=ft.Column([hum_fill], alignment=ft.MainAxisAlignment.END),
        width=bar_width,
        height=bar_height,
        bgcolor="grey"
    )

    # Containers individuais para cada barra com título e valor
    temp_container = ft.Column(
        [
            ft.Text("Temperatura", weight=ft.FontWeight.BOLD),
            temp_bar,
            temp_value
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=5
    )

    hum_container = ft.Column(
        [
            ft.Text("Humidade", weight=ft.FontWeight.BOLD),
            hum_bar,
            hum_value
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=5
    )

    # Container que agrupa as duas barras lado a lado
    bars_container = ft.Row(
        [temp_container, hum_container],
        spacing=40,
        alignment=ft.MainAxisAlignment.CENTER
    )

    # ================= GRÁFICO =================
    samples = 60
    temp_data = [0] * samples
    hum_data = [0] * samples
    time_data = list(range(samples))

    fig, ax = plt.subplots(figsize=(5, 3))
    ax.set_ylim(0, 100)
    ax.set_xlim(0, samples)
    ax.set_title("DHT11")
    ax.set_xlabel("Tempo")
    ax.set_ylabel("Valor")

    lt, = ax.plot(time_data, temp_data, label="Temperatura", color="red")
    lh, = ax.plot(time_data, hum_data, label="Humidade", color="blue")
    ax.legend()

    chart = MatplotlibChartWithToolbar(figure=fig, height=300)

    chart_container = ft.Container(
        content=chart,
        padding=10,
        bgcolor="#222222"
    )

    # Container principal que junta barras e gráfico lado a lado
    dht_main_container = ft.Row(
        [bars_container, chart_container],
        spacing=50,
        alignment=ft.MainAxisAlignment.CENTER
    )

    # ================= LDR =================
    ldr_text = ft.Text()
    ldr_bar = ft.ProgressBar(width=120, color="yellow")

    # ================= DISTÂNCIA =================
    dist_text = ft.Text()
    dist_bar = ft.ProgressBar(width=120, color="green")

    # ================= VENTOINHA =================
    fan_manual_led = ft.Icon(ft.Icons.CIRCLE, color="red", size=30)
    fan_manual_text = ft.Text("Ventoinha desligada")
    pir_led = ft.Icon(ft.Icons.CIRCLE, color="red", size=30)
    pir_text = ft.Text("Sem deteção")

    def fan_on_click(e): logic.fan_on()
    def fan_off_click(e): logic.fan_off()

    # ================= PWM =================
    pwm_slider = ft.Slider(min=0, max=100, divisions=100, width=300)

    pwm_mode = ft.RadioGroup(
        value="manual",
        content=ft.Row([
            ft.Radio(value="manual", label="Manual"),
            ft.Radio(value="auto", label="Automático")
        ])
    )

    async def pwm_slider_change(e):
        if logic.pwm_state["mode"] == "manual":
            logic.pwm_manual(pwm_slider.value)

    async def pwm_mode_change(e):
        if logic.pwm_state["task"]:
            logic.pwm_state["task"].cancel()

        if pwm_mode.value == "manual":
            logic.pwm_state["mode"] = "manual"
            pwm_slider.visible = True
            logic.pwm_manual(0)
        else:
            logic.pwm_state["mode"] = "auto"
            pwm_slider.visible = False
            logic.pwm_state["task"] = asyncio.create_task(logic.pwm_auto())

        page.update()

    pwm_slider.on_change = pwm_slider_change
    pwm_mode.on_change = pwm_mode_change

    # ================= SERVO =================
    servo_text = ft.Text("Ângulo: 90 °")
    servo_slider = ft.Slider(min=0, max=180, value=90, divisions=180)

    servo_mode = ft.RadioGroup(
        value="manual",
        content=ft.Row([
            ft.Radio(value="manual", label="Manual"),
            ft.Radio(value="auto", label="Automático")
        ])
    )

    def servo_manual(e):
        if servo_mode.value == "manual":
            ang = int(servo_slider.value)
            logic.servo_write(ang)
            servo_text.value = f"Ângulo: {ang} °"
            page.update()

    def servo_mode_changed(e):
        if servo_mode.value == "manual":
            logic.stop_servo_auto()
            servo_slider.visible = True
        else:
            servo_slider.visible = False
            logic.start_servo_auto(
                lambda ang: (
                    setattr(servo_text, "value", f"Ângulo: {ang} °"),
                    page.update()
                )
            )
        page.update()

    servo_slider.on_change = servo_manual
    servo_mode.on_change = servo_mode_changed

    # ================= BOTÃO SAIR =================
    async def on_exit(e):
        logic.stop_servo_auto()
        hardware.board.servo_write(hardware.SERVO_PIN, 90)
        await asyncio.sleep(0.3)
        hardware.board.digital_write(hardware.RELE_PIN, 0)
        if logic.pwm_state["task"]:
            logic.pwm_state["task"].cancel()
        if hasattr(hardware.board, "shutdown"):
            hardware.board.shutdown()
        await page.window.destroy()  # correto para Flet 0.8

    # ================= LOOP =================
    async def loop():
        while True:
            # --- DHT ---
            temp_value.value = f"{hardware.temperature:.1f} °C"
            hum_value.value = f"{hardware.humidity:.1f} %"

            temp_fill.height = min((hardware.temperature / 100) * bar_height, bar_height)
            hum_fill.height = min((hardware.humidity / 100) * bar_height, bar_height)

            temp_data.append(hardware.temperature)
            hum_data.append(hardware.humidity)
            temp_data.pop(0)
            hum_data.pop(0)

            lt.set_ydata(temp_data)
            lh.set_ydata(hum_data)
            chart.figure.canvas.draw_idle()

            # --- LDR ---
            ldr_v = hardware.ldr_value * 5 / 1023
            ldr_text.value = f"Luminosidade: {ldr_v:.2f} V"
            ldr_bar.value = ldr_v / 5

            # --- DISTÂNCIA ---
            dist_text.value = f"Distância: {hardware.distance_cm / 100:.2f} m"
            dist_bar.value = min(hardware.distance_cm / 200, 1)

            # --- VENTOINHA ---
            fan_on_state, auto_active = logic.update_fan()
            fan_manual_led.color = "green" if fan_on_state else "red"
            fan_manual_text.value = "Ventoinha ligada" if fan_on_state else "Ventoinha desligada"

            pir_led.color = "green" if auto_active else "red"
            pir_text.value = "Detetou objeto" if auto_active else "Sem deteção"

            page.update()
            await asyncio.sleep(0.2)

    # ================= UI =================
    page.add(
        ft.Column([
            ft.Text("DHT11"),
            dht_main_container,

            ft.Divider(),

            ft.Text("LDR"),
            ldr_text,
            ldr_bar,

            ft.Divider(),

            ft.Text("Ultrassónico"),
            dist_text,
            dist_bar,

            ft.Divider(),

            ft.Text("Ventoinha"),
            fan_manual_led,
            fan_manual_text,
            ft.Row([
                ft.Button("Ligar", on_click=fan_on_click),
                ft.Button("Desligar", on_click=fan_off_click)
            ]),
            ft.Row([pir_led, pir_text]),

            ft.Divider(),

            ft.Text("Motor PWM"),
            pwm_slider,
            pwm_mode,

            ft.Divider(),

            servo_text,
            servo_slider,
            servo_mode,

            ft.Divider(),

            ft.Button("Sair", icon=ft.Icons.EXIT_TO_APP, on_click=on_exit)
        ], spacing=15)
    )

    asyncio.create_task(loop())
